### Hexlet tests and linter status:
[![Actions Status](https://github.com/sp0on4/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sp0on4/python-project-49/actions)