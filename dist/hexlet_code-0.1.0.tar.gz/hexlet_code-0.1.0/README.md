### Hexlet tests and linter status:
[![Actions Status](https://github.com/sp0on4/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sp0on4/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f0ed847976ebe80e7e68/maintainability)](https://codeclimate.com/github/sp0on4/python-project-49/maintainability)

How to install:

[![asciicast](https://asciinema.org/a/AC30GYiUuNMc1lSNt7HVTeVsM.svg)](https://asciinema.org/a/AC30GYiUuNMc1lSNt7HVTeVsM)

brain-games and brain-even

[![asciicast](https://asciinema.org/a/kPw7dAoeqwao4uLvKGV7KtA5p.svg)](https://asciinema.org/a/kPw7dAoeqwao4uLvKGV7KtA5p)

brain-calc

[![asciicast](https://asciinema.org/a/8VUQCkXFa1ZoaAUyKvFxhkFTQ.svg)](https://asciinema.org/a/8VUQCkXFa1ZoaAUyKvFxhkFTQ)

brain-gcd

[![asciicast](https://asciinema.org/a/395GodMjptqfZkPsEqXiCkjKF.svg)](https://asciinema.org/a/395GodMjptqfZkPsEqXiCkjKF)

brain-progression

[![asciicast](https://asciinema.org/a/OTd8QruneW2PSn0lQgKLljr24.svg)](https://asciinema.org/a/OTd8QruneW2PSn0lQgKLljr24)

brain-prime

[![asciicast](https://asciinema.org/a/9SCMzL5DVtGFqSU533VAvIQzo.svg)](https://asciinema.org/a/9SCMzL5DVtGFqSU533VAvIQzo)
