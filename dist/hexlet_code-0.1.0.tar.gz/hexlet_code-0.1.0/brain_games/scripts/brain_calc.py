#!/usr/bin/env python3
from brain_games.games.calc import calc_func


def main():
    calc_func()


if __name__ == '__main__':
    main()
