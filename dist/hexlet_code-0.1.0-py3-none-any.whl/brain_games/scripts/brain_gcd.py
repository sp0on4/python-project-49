#!/usr/bin/env python3
from brain_games.games.gcd import gcd_func


def main():
    gcd_func()


if __name__ == '__main__':
    main()
