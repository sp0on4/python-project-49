#!/usr/bin/env python3
from brain_games.even import even_func


def main():
    even_func()  # приветствие


if __name__ == '__main__':
    main()
