#!/usr/bin/env python3
from brain_games.games.progression import progression_func


def main():
    progression_func()


if __name__ == '__main__':
    main()
